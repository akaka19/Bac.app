package ma.bacplusmaroc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val branches = listOf(
    "العلوم الفيزيائية", "علوم الحياة والأرض", "العلوم الرياضية أ",
    "العلوم الرياضية ب", "العلوم الاقتصادية", "علوم التدبير المحاسباتي",
    "الآداب", "العلوم الإنسانية", "التعليم الأصيل", "الفنون التطبيقية",
    "المسالك المهنية والتقنية"
)

private val subjects = listOf("الرياضيات", "الفيزياء والكيمياء", "علوم الحياة والأرض", "الفلسفة", "اللغة العربية", "اللغة الفرنسية", "اللغة الإنجليزية")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BacPlusApp() }
    }
}

@Composable
fun BacPlusApp() {
    var dark by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var selectedBranch by remember { mutableStateOf(branches.first()) }
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF62D6C8),
        secondary = Color(0xFF9DB7FF),
        background = Color(0xFF0B1020),
        surface = Color(0xFF151D30),
        onBackground = Color(0xFFF2F5FC),
        onSurface = Color(0xFFF2F5FC)
    ) else lightColorScheme(
        primary = Color(0xFF087F8C),
        secondary = Color(0xFF415CA8),
        background = Color(0xFFF5F7FB),
        surface = Color.White
    )

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    TopAppBarBac(
                        dark = dark,
                        onToggleTheme = { dark = !dark }
                    )
                },
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        val tabs = listOf(
                            "الرئيسية" to Icons.Default.Home,
                            "المكتبة" to Icons.Default.MenuBook,
                            "خطتي" to Icons.Default.CalendarMonth,
                            "المحفوظات" to Icons.Default.Bookmark,
                            "المزيد" to Icons.Default.MoreHoriz
                        )
                        tabs.forEach { (label, icon) ->
                            NavigationBarItem(
                                selected = selectedTab == label,
                                onClick = { selectedTab = label },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            ) { padding ->
                when (selectedTab) {
                    "الرئيسية" -> HomeScreen(
                        padding = padding,
                        branch = selectedBranch,
                        onBranchChange = { selectedBranch = it },
                        onNavigate = { selectedTab = it }
                    )
                    "المكتبة" -> LibraryScreen(padding, selectedBranch, { selectedBranch = it })
                    "خطتي" -> StudyPlanScreen(padding)
                    "المحفوظات" -> SimpleScreen(padding, "المحفوظات", "الدروس والملخصات اللي غادي تحفظ غادي يبانوا هنا.")
                    else -> MoreScreen(padding, onAdmin = { selectedTab = "الإدارة" })
                }
            }
        }
    }
}

@Composable
fun TopAppBarBac(dark: Boolean, onToggleTheme: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("BAC PLUS", fontWeight = FontWeight.Black, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
            Text("طريقك نحو النجاح", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
        }
        IconButton(onClick = onToggleTheme) {
            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "تغيير المظهر")
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, branch: String, onBranchChange: (String) -> Unit, onNavigate: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("مرحبا بك 👋", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color(0xFF061722))
                    Spacer(Modifier.height(6.dp))
                    Text("وجد راسك للباك خطوة بخطوة.", fontSize = 15.sp, color = Color(0xFF061722))
                    Spacer(Modifier.height(16.dp))
                    Text("الشعبة ديالك", fontWeight = FontWeight.SemiBold, color = Color(0xFF061722))
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF061722))) {
                            Text(branch, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            branches.forEach { b ->
                                DropdownMenuItem(text = { Text(b) }, onClick = { onBranchChange(b); expanded = false })
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("شنو نقرا دابا؟", "خطة بسيطة حسب الوقت اللي عندك") }
        item {
            FeatureCard("خطة اليوم", "اختار الوقت والمواد والأولوية ديالك", Icons.Default.Today, "بدا التخطيط") {
                onNavigate("خطتي")
            }
        }
        item { SectionTitle("تعلّم وراجع", "كلشي منظم حسب الشعبة والمادة") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallFeature("الدروس", Icons.Default.MenuBook, Modifier.weight(1f)) { onNavigate("المكتبة") }
                SmallFeature("ملخص فصفحة", Icons.Default.AutoStories, Modifier.weight(1f)) { onNavigate("المكتبة") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallFeature("الامتحانات الوطنية", Icons.Default.Quiz, Modifier.weight(1f)) { onNavigate("المكتبة") }
                SmallFeature("المحفوظات", Icons.Default.Bookmark, Modifier.weight(1f)) { onNavigate("المحفوظات") }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.OfflinePin, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("قرا حتى بلا إنترنت", fontWeight = FontWeight.Bold)
                        Text("حمّل المحتوى اللي محتاج وخليه عندك فالتليفون.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(padding: PaddingValues, branch: String, onBranchChange: (String) -> Unit) {
    var filter by remember { mutableStateOf("الدروس") }
    var branchExpanded by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("المكتبة الدراسية", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        item {
            Box {
                OutlinedButton(onClick = { branchExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(branch, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = branchExpanded, onDismissRequest = { branchExpanded = false }) {
                    branches.forEach { b -> DropdownMenuItem(text = { Text(b) }, onClick = { onBranchChange(b); branchExpanded = false }) }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("الدروس", "ملخص فصفحة", "الامتحانات").forEach {
                    FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it, fontSize = 12.sp) })
                }
            }
        }
        items(subjects) { subject ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .14f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Icon(if (filter == "الامتحانات") Icons.Default.Quiz else Icons.Default.MenuBook, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(subject, fontWeight = FontWeight.Bold)
                        Text("$branch • $filter", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                    }
                    Icon(Icons.Default.ChevronLeft, null)
                }
            }
        }
        item {
            Text("ملاحظة: هاد النسخة هي الهيكل الأولي. خاص ربط المكتبة بمحتوى موثوق ومراجع قبل الاستعمال الدراسي الفعلي.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        }
    }
}

@Composable
fun StudyPlanScreen(padding: PaddingValues) {
    var hours by remember { mutableStateOf(2f) }
    var priority by remember { mutableStateOf("مراجعة الدروس") }
    var examDate by remember { mutableStateOf("قريب") }
    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("شنو نقرا دابا؟", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        item { Text("حدد الوقت ديالك والأولوية، وغادي نقترحو عليك تقسيمة أولية لوقت المراجعة.") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("شحال عندك من الوقت اليوم؟", fontWeight = FontWeight.Bold)
                    Text("${hours.toInt()} ساعات")
                    Slider(value = hours, onValueChange = { hours = it }, valueRange = 1f..6f, steps = 4)
                    Text("الهدف ديالك", fontWeight = FontWeight.Bold)
                    listOf("مراجعة الدروس", "حل التمارين", "التحضير للامتحان").forEach {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = priority == it, onClick = { priority = it })
                            Text(it)
                        }
                    }
                    Text("موعد الامتحان", fontWeight = FontWeight.Bold)
                    listOf("قريب", "من بعد", "مازال ما تحددش").forEach {
                        FilterChip(selected = examDate == it, onClick = { examDate = it }, label = { Text(it) })
                    }
                }
            }
        }
        item {
            Text("البرنامج المقترح", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            val totalMinutes = hours.toInt() * 60
            val first = totalMinutes / 2
            val second = totalMinutes / 3
            val third = totalMinutes - first - second
            PlanRow("الحصة 1", "$first دقيقة", priority)
            PlanRow("الحصة 2", "$second دقيقة", "تمارين تطبيقية")
            PlanRow("الحصة 3", "$third دقيقة", "مراجعة سريعة وراحة قصيرة")
            Text("هاد التقسيمة اقتراح أولي فقط، ومازال ما كتتحفظش وما كتتكيفش تلقائياً مع نتائجك.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        }
    }
}

@Composable
fun PlanRow(title: String, time: String, detail: String) {
    Card(Modifier.fillMaxWidth().padding(top = 8.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CheckCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(detail, fontSize = 13.sp) }
            Text(time, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun MoreScreen(padding: PaddingValues, onAdmin: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("المزيد", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        item { FeatureCard("الإعدادات", "المظهر واللغة وتفضيلات التطبيق", Icons.Default.Settings, "فتح") {} }
        item { FeatureCard("حول التطبيق", "Bac Plus Maroc — مساعد المراجعة للباك المغربي", Icons.Default.Info, "معلومات") {} }
        item { FeatureCard("إدارة المحتوى", "خاصها تسجيل دخول آمن وربط بخدمة خلفية", Icons.Default.AdminPanelSettings, "معاينة") { onAdmin() } }
        item { Text("الإدارة هنا غير واجهة توضيحية. ما كاين لا تسجيل دخول حقيقي لا رفع محتوى فهاد النسخة.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)) }
    }
}

@Composable
fun SimpleScreen(padding: PaddingValues, title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, actionLabel: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)) }
            Text(actionLabel, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
    }
}

@Composable
fun SmallFeature(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable { onClick() }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
}
