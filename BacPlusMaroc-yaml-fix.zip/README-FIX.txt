# Fix for GitHub Actions Gradle root error

1. Replace the workflow at `.github/workflows/build-apk.yml` with the included YAML.
2. Make sure the repository actually contains the Android project files, including `settings.gradle.kts`, `build.gradle.kts`, and `app/build.gradle.kts`.
3. If your ZIP was uploaded as a single ZIP file into the repository, GitHub Actions will not automatically extract it. Extract the project files into the repository so the Gradle files are visible.
4. Commit and push, then rerun Actions.

This workflow searches for `settings.gradle` or `settings.gradle.kts` and builds from the directory containing it. It will stop with a clear error if no Gradle settings file is found.
